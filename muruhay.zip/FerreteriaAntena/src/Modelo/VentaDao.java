
package Modelo;
import Modelo.Venta;
import Vista.Sistema;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.filechooser.FileSystemView;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class VentaDao {
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public int IdVenta(){
        int id = 0;
        String sql = "SELECT MAX(id) FROM ventas";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return id;
    }
    public int RegistrarVenta(Venta v) {
    String sql = "INSERT INTO ventas (cliente, vendedor, total, metodopago, fecha) VALUES (?, ?, ?, ?, ?)";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setString(1, v.getCliente());
        ps.setString(2, v.getVendedor());
        ps.setDouble(3, v.getTotal());
        ps.setString(4, v.getMetodopago());
        ps.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now())); // usa la hora actual
        ps.execute();
    } catch (SQLException e) {
        System.out.println(e.toString());
    } finally {
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    return r;
}

    public int RegistrarDetalle(Detalle Dv){
       String sql = "INSERT INTO detalle (cod_pro, cantidad, precio, id_venta) VALUES (?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, Dv.getCod_pro());
            ps.setInt(2, Dv.getCantidad());
            ps.setDouble(3, Dv.getPrecio());
            ps.setInt(4, Dv.getId());
            ps.execute();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }finally{
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
        }
        return r;
    }
    
    public boolean ActualizarStock(int cant, String cod){
        String sql = "UPDATE productos SET stock = ? WHERE codigo = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1,cant);
            ps.setString(2, cod);
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }
    
    public List Listarventas(){
    List<Venta> ListaVenta = new ArrayList();
    String sql = "SELECT * FROM ventas";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        rs = ps.executeQuery();
        while (rs.next()) {
            Venta vent = new Venta();
            vent.setId(rs.getInt("id"));
            vent.setCliente(rs.getString("cliente"));
            vent.setVendedor(rs.getString("vendedor"));
            vent.setTotal(rs.getDouble("total"));
            vent.setMetodopago(rs.getString("metodopago"));

            // ✅ Leer fecha con hora
            vent.setFecha(rs.getTimestamp("fecha").toString());

            ListaVenta.add(vent);
        }
    } catch (SQLException e) {
        System.out.println(e.toString());
    }
    return ListaVenta;
}
   public Venta BuscarVenta(int id){
    Venta cl = new Venta();
    String sql = "SELECT * FROM ventas WHERE id = ?";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setInt(1, id);
        rs = ps.executeQuery();
        if (rs.next()) {
            cl.setId(rs.getInt("id"));
            cl.setCliente(rs.getString("cliente"));
            cl.setTotal(rs.getDouble("total"));
            cl.setVendedor(rs.getString("vendedor"));
            cl.setMetodopago(rs.getString("metodopago"));

            // ✅ Obtener fecha como DATETIME
            cl.setFecha(rs.getTimestamp("fecha").toString());
        }
    } catch (SQLException e) {
        System.out.println(e.toString());
    }
    return cl;
}
    public void pdfV(int idventa, int Cliente, double total, String usuario) {
    try {
        String fechaVenta = "";
        String sqlFecha = "SELECT fecha FROM ventas WHERE id = ?";
        con = cn.getConnection();
        ps = con.prepareStatement(sqlFecha);
        ps.setInt(1, idventa);
        rs = ps.executeQuery();
        if (rs.next()) {
            Timestamp timestamp = rs.getTimestamp("fecha");
            fechaVenta = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(timestamp);
        }

        FileOutputStream archivo;
        String url = FileSystemView.getFileSystemView().getDefaultDirectory().getPath();
        File salida = new File(url + File.separator + "venta.pdf");
        archivo = new FileOutputStream(salida);
        Document doc = new Document();
        PdfWriter.getInstance(doc, archivo);
        doc.open();
        Image img = Image.getInstance(getClass().getResource("/Img/logo_pdf.png"));
        Paragraph fecha = new Paragraph();
        Font negrita = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLUE);
        fecha.add(Chunk.NEWLINE);
        fecha.add("Vendedor: " + usuario + "\nFolio: " + idventa + "\nFecha: " + fechaVenta + "\n\n");

        PdfPTable Encabezado = new PdfPTable(4);
        Encabezado.setWidthPercentage(100);
        Encabezado.getDefaultCell().setBorder(0);
        float[] columnWidthsEncabezado = new float[]{20f, 30f, 70f, 40f};
        Encabezado.setWidths(columnWidthsEncabezado);
        Encabezado.setHorizontalAlignment(Element.ALIGN_LEFT);
        Encabezado.addCell(img);
        Encabezado.addCell("");
        // info empresa
        String config = "SELECT * FROM config";
        String mensaje = "";
        try {
            ps = con.prepareStatement(config);
            rs = ps.executeQuery();
            if (rs.next()) {
                mensaje = rs.getString("mensaje");
                Encabezado.addCell("Ruc:    " + rs.getString("ruc") + "\nNombre: " + rs.getString("nombre") + "\nTeléfono: " + rs.getString("telefono") + "\nDirección: " + rs.getString("direccion") + "\n\n");
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }

        Encabezado.addCell(fecha);
        doc.add(Encabezado);

        // Cliente
        Paragraph cli = new Paragraph();
        cli.add(Chunk.NEWLINE);
        cli.add("DATOS DEL CLIENTE" + "\n\n");
        doc.add(cli);

        PdfPTable proveedor = new PdfPTable(3);
        proveedor.setWidthPercentage(100);
        proveedor.getDefaultCell().setBorder(0);
        float[] columnWidthsCliente = new float[]{50f, 25f, 25f};
        proveedor.setWidths(columnWidthsCliente);
        proveedor.setHorizontalAlignment(Element.ALIGN_LEFT);
        PdfPCell cliNom = new PdfPCell(new Phrase("Nombre", negrita));
        PdfPCell cliTel = new PdfPCell(new Phrase("Télefono", negrita));
        PdfPCell cliDir = new PdfPCell(new Phrase("Dirección", negrita));
        cliNom.setBorder(Rectangle.NO_BORDER);
        cliTel.setBorder(Rectangle.NO_BORDER);
        cliDir.setBorder(Rectangle.NO_BORDER);
        proveedor.addCell(cliNom);
        proveedor.addCell(cliTel);
        proveedor.addCell(cliDir);

        String prove = "SELECT * FROM clientes WHERE id = ?";
        try {
            ps = con.prepareStatement(prove);
            ps.setInt(1, Cliente);
            rs = ps.executeQuery();
            if (rs.next()) {
                proveedor.addCell(rs.getString("nombre"));
                proveedor.addCell(rs.getString("telefono"));
                proveedor.addCell(rs.getString("direccion") + "\n\n");
            } else {
                proveedor.addCell("Publico en General");
                proveedor.addCell("S/N");
                proveedor.addCell("S/N" + "\n\n");
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }

        doc.add(proveedor);

        PdfPTable tabla = new PdfPTable(4);
        tabla.setWidthPercentage(100);
        tabla.getDefaultCell().setBorder(0);
        float[] columnWidths = new float[]{10f, 50f, 15f, 15f};
        tabla.setWidths(columnWidths);
        tabla.setHorizontalAlignment(Element.ALIGN_LEFT);
        PdfPCell c1 = new PdfPCell(new Phrase("Cant.", negrita));
        PdfPCell c2 = new PdfPCell(new Phrase("Descripción.", negrita));
        PdfPCell c3 = new PdfPCell(new Phrase("P. unt.", negrita));
        PdfPCell c4 = new PdfPCell(new Phrase("P. Total", negrita));
        c1.setBorder(Rectangle.NO_BORDER);
        c2.setBorder(Rectangle.NO_BORDER);
        c3.setBorder(Rectangle.NO_BORDER);
        c4.setBorder(Rectangle.NO_BORDER);
        c1.setBackgroundColor(BaseColor.LIGHT_GRAY);
        c2.setBackgroundColor(BaseColor.LIGHT_GRAY);
        c3.setBackgroundColor(BaseColor.LIGHT_GRAY);
        c4.setBackgroundColor(BaseColor.LIGHT_GRAY);
        tabla.addCell(c1);
        tabla.addCell(c2);
        tabla.addCell(c3);
        tabla.addCell(c4);

        String product = "SELECT d.id, d.id_pro,d.id_venta, d.precio, d.cantidad, p.id, p.nombre FROM detalle d INNER JOIN productos p ON d.id_pro = p.id WHERE d.id_venta = ?";
        try {
            ps = con.prepareStatement(product);
            ps.setInt(1, idventa);
            rs = ps.executeQuery();
            while (rs.next()) {
                double subTotal = rs.getInt("cantidad") * rs.getDouble("precio");
                tabla.addCell(rs.getString("cantidad"));
                tabla.addCell(rs.getString("nombre"));
                tabla.addCell(rs.getString("precio"));
                tabla.addCell(String.valueOf(subTotal));
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }

        doc.add(tabla);
        Paragraph info = new Paragraph();
        info.add(Chunk.NEWLINE);
        info.add("Total S/: " + total);
        info.setAlignment(Element.ALIGN_RIGHT);
        doc.add(info);

        Paragraph firma = new Paragraph();
        firma.add(Chunk.NEWLINE);
        firma.add("Cancelacion \n\n");
        firma.add("------------------------------------\n");
        firma.add("Firma \n");
        firma.setAlignment(Element.ALIGN_CENTER);
        doc.add(firma);

        Paragraph gr = new Paragraph();
        gr.add(Chunk.NEWLINE);
        gr.add(mensaje);
        gr.setAlignment(Element.ALIGN_CENTER);
        doc.add(gr);

        doc.close();
        archivo.close();
        Desktop.getDesktop().open(salida);
    } catch (DocumentException | IOException | SQLException e) {
        System.out.println(e.toString());
    }
}
}
