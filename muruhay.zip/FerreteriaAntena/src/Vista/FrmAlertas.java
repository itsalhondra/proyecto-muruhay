
package Vista;
import javax.swing.*;
import java.sql.*;
public class FrmAlertas extends javax.swing.JFrame {

int xMouse, yMouse;
    public FrmAlertas() {
        setUndecorated(true);
        initComponents();
        cargarAlertas();
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE); 
        setLocationRelativeTo(null);
    }
    private void cargarAlertas() {
    DefaultListModel modeloLista = new DefaultListModel();
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3309/dbbodegaluis", "root", "");
        String sql = "SELECT mensaje FROM alertas WHERE estado = 'activa'";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            modeloLista.addElement("🔔 " + rs.getString("mensaje"));
        }

        if (modeloLista.isEmpty()) {
            modeloLista.addElement("No hay alertas activas.");
        }

        lstAlertas.setModel(modeloLista);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar alertas: " + e.getMessage());
    }
}
     private void marcarAlertasComoVistas() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3309/dbbodegaluis", "root", "");
            String sql = "UPDATE alertas SET estado='inactiva' WHERE estado='activa'";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar alertas: " + e.getMessage());
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnCerrarAlerta = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstAlertas = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setResizable(false);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });

        btnCerrarAlerta.setBackground(new java.awt.Color(255, 102, 102));
        btnCerrarAlerta.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCerrarAlerta.setForeground(new java.awt.Color(255, 255, 255));
        btnCerrarAlerta.setText("CERRAR");
        btnCerrarAlerta.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCerrarAlerta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarAlertaActionPerformed(evt);
            }
        });

        lstAlertas.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "NOTIFICACIONES", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Black", 1, 18))); // NOI18N
        lstAlertas.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        lstAlertas.setEnabled(false);
        jScrollPane1.setViewportView(lstAlertas);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(btnCerrarAlerta, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCerrarAlerta, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCerrarAlertaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarAlertaActionPerformed
            try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3309/dbbodegaluis", "root", "");
        String sql = "UPDATE alertas SET estado='inactiva' WHERE estado='activa'";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.executeUpdate();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al actualizar alertas: " + e.getMessage());
    }
    marcarAlertasComoVistas();
    this.dispose();

    }//GEN-LAST:event_btnCerrarAlertaActionPerformed

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_formMousePressed

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        FrmAlertas.this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_formMouseDragged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmAlertas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmAlertas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmAlertas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmAlertas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmAlertas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrarAlerta;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lstAlertas;
    // End of variables declaration//GEN-END:variables
}
