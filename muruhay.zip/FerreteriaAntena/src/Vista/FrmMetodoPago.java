
package Vista;

import javax.swing.table.DefaultTableModel;


public class FrmMetodoPago extends javax.swing.JFrame {
 
Sistema sistema;
//Poder Mover el formulario
int xMouse, yMouse;
public FrmMetodoPago(Sistema sistema) {
    setUndecorated(true);
    initComponents();
    this.sistema = sistema;
    // Mostrar la boleta apenas se abra
    txtBoletaEfectivo();
    jTabbedPane1.setSelectedIndex(0);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(FrmMetodoPago.DISPOSE_ON_CLOSE);
    
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnRegresarPago = new javax.swing.JButton();
        btnEfectivo = new javax.swing.JButton();
        btnYape = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        btnConEfec = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txaPreEfec = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txaPreYape = new javax.swing.JTextArea();
        btnConYape = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnRegresarPago.setBackground(new java.awt.Color(0, 204, 204));
        btnRegresarPago.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresarPago.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresarPago.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/salir_1.png"))); // NOI18N
        btnRegresarPago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarPagoActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegresarPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 30, -1));

        btnEfectivo.setBackground(new java.awt.Color(102, 255, 255));
        btnEfectivo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEfectivo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/money.png"))); // NOI18N
        btnEfectivo.setText("P. EFECTIVO");
        btnEfectivo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEfectivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEfectivoActionPerformed(evt);
            }
        });
        getContentPane().add(btnEfectivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 130, 30));

        btnYape.setBackground(new java.awt.Color(102, 255, 255));
        btnYape.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnYape.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/logo-yape-NEGRO (1).png"))); // NOI18N
        btnYape.setText("P. ELECTRONICO");
        btnYape.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnYape.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYapeActionPerformed(evt);
            }
        });
        getContentPane().add(btnYape, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 150, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/color negro.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 70));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "METODO EN EFECTIVO", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnConEfec.setBackground(new java.awt.Color(51, 51, 255));
        btnConEfec.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnConEfec.setForeground(new java.awt.Color(255, 255, 255));
        btnConEfec.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/compras.png"))); // NOI18N
        btnConEfec.setText("CONTINUAR");
        btnConEfec.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnConEfec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConEfecActionPerformed(evt);
            }
        });
        jPanel1.add(btnConEfec, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 260, 40));

        txaPreEfec.setColumns(20);
        txaPreEfec.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        txaPreEfec.setRows(5);
        txaPreEfec.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "PREVISUALISACIÓN:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jScrollPane2.setViewportView(txaPreEfec);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 370, 170));

        jTabbedPane1.addTab("tab1", jPanel1);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "METODO DE PAGO ELECTRONICO", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txaPreYape.setColumns(20);
        txaPreYape.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        txaPreYape.setRows(5);
        txaPreYape.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "PREVISUALISACIÓN:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jScrollPane3.setViewportView(txaPreYape);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 370, 170));

        btnConYape.setBackground(new java.awt.Color(51, 51, 255));
        btnConYape.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnConYape.setForeground(new java.awt.Color(255, 255, 255));
        btnConYape.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/compras.png"))); // NOI18N
        btnConYape.setText("CONTINUAR");
        btnConYape.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnConYape.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConYapeActionPerformed(evt);
            }
        });
        jPanel2.add(btnConYape, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 260, 40));

        jTabbedPane1.addTab("tab2", jPanel2);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 36, 390, 310));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnConEfecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConEfecActionPerformed
    FrmPagoEfectivo pa = new FrmPagoEfectivo(sistema); // pasamos metodos de el sistema actual
    pa.setVisible(true);
    this.setVisible(false); // ocultar
    FrmMetodoPago.this.dispose();
    sistema.TotalPagar.setText("---------");
    }//GEN-LAST:event_btnConEfecActionPerformed

    private void btnConYapeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConYapeActionPerformed
        FrmPagoElectronico pag = new FrmPagoElectronico(sistema);
        pag.setVisible(true);
        this.setVisible(false); // ocultar
        FrmMetodoPago.this.dispose();
        sistema.TotalPagar.setText("---------");
    }//GEN-LAST:event_btnConYapeActionPerformed

    private void btnYapeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYapeActionPerformed
    String textoBoleta = sistema.generarTextoBoleta();
    txaPreYape.setText(textoBoleta); // o el JTextArea del tab Yape
    jTabbedPane1.setSelectedIndex(1); // ir al tab Yape
    }//GEN-LAST:event_btnYapeActionPerformed

    private void btnEfectivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEfectivoActionPerformed
    String textoBoleta = sistema.generarTextoBoleta();
    txaPreEfec.setText(textoBoleta); 
    jTabbedPane1.setSelectedIndex(0); 
    }//GEN-LAST:event_btnEfectivoActionPerformed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
 
    }//GEN-LAST:event_formKeyPressed

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        FrmMetodoPago.this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_formMouseDragged

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_formMousePressed

    private void btnRegresarPagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarPagoActionPerformed
        sistema.setVisible(true);// La muestra
        this.dispose();        
    }//GEN-LAST:event_btnRegresarPagoActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConEfec;
    private javax.swing.JButton btnConYape;
    private javax.swing.JButton btnEfectivo;
    private javax.swing.JButton btnRegresarPago;
    private javax.swing.JButton btnYape;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea txaPreEfec;
    private javax.swing.JTextArea txaPreYape;
    // End of variables declaration//GEN-END:variables

private void txtBoletaEfectivo() {
    StringBuilder sb = new StringBuilder();
    sb.append("========= BOLETA =========\n");
    sb.append("Cliente: ").append(sistema.txtNombreClienteventa.getText()).append("\n");
    sb.append("Vendedor: ").append(sistema.LabelVendedor.getText()).append("\n");
    sb.append("Total: S/ ").append(sistema.TotalPagar.getText()).append("\n");
    sb.append("===========================\n");
    sb.append("Detalle:\n");

    DefaultTableModel model = (DefaultTableModel) sistema.TableVenta.getModel();
    for (int i = 0; i < model.getRowCount(); i++) {
        String producto = model.getValueAt(i, 1).toString();
        String cantidad = model.getValueAt(i, 2).toString();
        String precio = model.getValueAt(i, 3).toString();
        sb.append(cantidad).append(" x ").append(producto).append(" (S/").append(precio).append(")\n");
    }

    txaPreEfec.setText(sb.toString());
}

}
