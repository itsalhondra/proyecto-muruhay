package Vista;

import Modelo.Cliente;
import Modelo.Proveedor;
import Modelo.Productos;
import Modelo.ClienteDAO;
import Modelo.ProveedorDao;
import Modelo.ProductosDao;
import java.util.List;

public class FrmChatBot extends javax.swing.JFrame {
    
    public FrmChatBot(String nombreVendedor) {
    initComponents();
    this.setLocationRelativeTo(null);
    setTitle("Asistente Virtual 🤖");
    setDefaultCloseOperation(FrmChatBot.DISPOSE_ON_CLOSE);
    
    // Mensaje inicial al cargar el formulario
    String mensajeBienvenida = "🤖 ¡Hola " + nombreVendedor + "! Soy tu asistente virtual.\n\n"
        + "Estas son algunas cosas que puedo hacer por ti:\n"
        + "✅ Registrar un cliente: cliente:12345678,Juan Pérez,987654321,Lima,Consumidor Final\n"
        + "✅ Registrar un proveedor: proveedor:12345678901,Proveedor SAC,987654321,Lima,Mayorista\n"
        + "✅ Registrar un producto: producto:ABC123,Martillo,Proveedor SAC,50,12.99\n"
        + "✅ Buscar productos por nombre: buscar:Martillo\n\n"
        + "💬 Escribe tu solicitud a continuación:";

    txaConversacion.setText(mensajeBienvenida);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txaConversacion = new javax.swing.JTextArea();
        txtMensaje = new javax.swing.JTextField();
        btnEnviar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txaConversacion.setColumns(20);
        txaConversacion.setFont(new java.awt.Font("Rockwell", 0, 12)); // NOI18N
        txaConversacion.setRows(5);
        txaConversacion.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "CHAT BOT", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N
        jScrollPane1.setViewportView(txaConversacion);

        txtMensaje.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Consulta:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        btnEnviar.setBackground(new java.awt.Color(51, 102, 255));
        btnEnviar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEnviar.setForeground(new java.awt.Color(255, 255, 255));
        btnEnviar.setText("ENVIAR");
        btnEnviar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE)
                    .addComponent(txtMensaje))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(146, 146, 146)
                .addComponent(btnEnviar, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(txtMensaje, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEnviar, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
       String mensaje = txtMensaje.getText().trim();
    if (mensaje.isEmpty()) {
        return;
    }

    String respuestaBot = procesarMensaje(mensaje);
    txaConversacion.append("\n👤 Tú: " + mensaje);
    txaConversacion.append("\n🤖 ChatBot: " + respuestaBot + "\n");
    txtMensaje.setText("");
    }//GEN-LAST:event_btnEnviarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEnviar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txaConversacion;
    private javax.swing.JTextField txtMensaje;
    // End of variables declaration//GEN-END:variables

    private String procesarMensaje(String mensaje) {
    if (mensaje.toLowerCase().startsWith("cliente:")) {
        return registrarCliente(mensaje);
    } else if (mensaje.toLowerCase().startsWith("proveedor:")) {
        return registrarProveedor(mensaje);
    } else if (mensaje.toLowerCase().startsWith("producto:")) {
        return registrarProducto(mensaje);
    } else if (mensaje.toLowerCase().startsWith("buscar:")) {
        return buscarProducto(mensaje);
    } else {
        return "Lo siento, no entendí. Intenta usar comandos como:\n"
             + "cliente:12345678,Juan Pérez,987654321,Lima,Consumidor Final\n"
             + "proveedor:12345678901,Proveedor SAC,987654321,Lima,Mayorista\n"
             + "producto:ABC123,Martillo,Proveedor SAC,50,12.99\n"
             + "buscar:martillo";
    }
}
    private String registrarCliente(String msg) {
    try {
        String[] partes = msg.substring(8).split(",");
        if (partes.length < 5) return "Formato incorrecto. Debe ser: dni,nombre,telefono,direccion,razon";
        
        Cliente c = new Cliente();
        c.setDni(Integer.parseInt(partes[0]));
        c.setNombre(partes[1]);
        c.setTelefono(Integer.parseInt(partes[2]));
        c.setDireccion(partes[3]);
        c.setRazon(partes[4]);

        ClienteDAO dao = new ClienteDAO();
        dao.RegistrarCliente(c);
        return "Cliente registrado con éxito ✅";
    } catch (Exception e) {
        return "Error al registrar cliente: " + e.getMessage();
    }
}
private String registrarProveedor(String msg) {
    try {
        String[] partes = msg.substring(10).split(",");
        if (partes.length < 5) return "Formato incorrecto. Debe ser: ruc,nombre,telefono,direccion,razon";

        Proveedor p = new Proveedor();
        p.setRuc(Integer.parseInt(partes[0]));
        p.setNombre(partes[1]);
        p.setTelefono(Integer.parseInt(partes[2])); // 👈 corregido aquí
        p.setDireccion(partes[3]);
        p.setRazon(partes[4]);

        ProveedorDao dao = new ProveedorDao();
        dao.RegistrarProveedor(p);
        return "Proveedor registrado con éxito ✅";
    } catch (Exception e) {
        return "Error al registrar proveedor: " + e.getMessage();
    }
}
private String registrarProducto(String msg) {
    try {
        String[] partes = msg.substring(9).split(",");
        if (partes.length < 5) return "Formato: codigo,nombre,proveedor,stock,precio";

        // ✅ Usar ProveedorDao en lugar de ProductosDao
        ProveedorDao proveedorDao = new ProveedorDao();
        List<Proveedor> lista = proveedorDao.ListarProveedor();

        boolean existeProveedor = lista.stream()
            .anyMatch(p -> p.getNombre().equalsIgnoreCase(partes[2]));

        if (!existeProveedor) {
            return "Proveedor no encontrado. Regístralo primero con:\nproveedor:ruc,nombre,telefono,direccion,razon";
        }

        // Registrar producto
        Productos prod = new Productos();
        prod.setCodigo(partes[0]);
        prod.setNombre(partes[1]);
        prod.setProveedor(partes[2]);
        prod.setStock(Integer.parseInt(partes[3]));
        prod.setPrecio(Double.parseDouble(partes[4]));

        ProductosDao dao = new ProductosDao();
        dao.RegistrarProductos(prod);

        return "Producto registrado correctamente ✅";

    } catch (Exception e) {
        return "Error al registrar producto: " + e.getMessage();
    }
}

private String buscarProducto(String msg) {
    try {
        String nombre = msg.substring(11).trim(); // después de 'buscar '
        ProductosDao dao = new ProductosDao();
        List<Productos> lista = dao.BuscarListaPorNombre(nombre); // 👈 nombre correcto del método

        if (lista.isEmpty()) return "No se encontraron productos con ese nombre.";

        StringBuilder sb = new StringBuilder("Resultados:\n");
        for (Productos p : lista) {
            sb.append("🆔 ").append(p.getId()).append(" | ")
              .append("Cod:").append(p.getCodigo()).append("|Nombre:")
              .append(p.getNombre()).append(" - S/ ").append(p.getPrecio()).append(" (Stock: ")
              .append(p.getStock()).append(")\n");
        }
        return sb.toString();
    } catch (Exception e) {
        return "Error al buscar: " + e.getMessage();
    }
}
}


