
package Main;

import Vista.FrmSistemaFA;


public class SistemaFA {

    public static void main(String[] args) {
       FrmSistemaFA lg = new FrmSistemaFA();
        lg.setVisible(true); 
    }
    
}
