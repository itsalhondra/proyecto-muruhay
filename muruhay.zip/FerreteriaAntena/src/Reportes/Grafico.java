
package Reportes;

import Modelo.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

public class Grafico {
  public static void Graficar(String fecha, String turno) {
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;

    String horaInicio = "06:00:00";
    String horaFin = "13:59:59";

    if (turno.equalsIgnoreCase("Tarde")) {
        horaInicio = "14:00:00";
        horaFin = "20:59:59";
    }

    // ✅ Armar el rango DATETIME
    String inicio = fecha + " " + horaInicio;
    String fin = fecha + " " + horaFin;

    try {
        String sql = "SELECT id, total FROM ventas WHERE fecha BETWEEN ? AND ?";
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setString(1, inicio);
        ps.setString(2, fin);
        rs = ps.executeQuery();

        DefaultPieDataset dataset = new DefaultPieDataset();
        boolean tieneDatos = false;

        while (rs.next()) {
            tieneDatos = true;
            int id = rs.getInt("id");
            double total = rs.getDouble("total");
            String etiqueta = "Venta #" + id + " - S/ " + total;
            dataset.setValue(etiqueta, total);
        }

        if (!tieneDatos) {
            JOptionPane.showMessageDialog(null, "No hay ventas registradas en ese turno.");
            return;
        }

        JFreeChart chart = ChartFactory.createPieChart(
            "Ventas del Turno " + turno + " (" + fecha + ")",
            dataset,
            true,
            true,
            false
        );

        ChartFrame frame = new ChartFrame("Total de Ventas por Turno", chart);
        frame.setSize(900, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al graficar: " + e.getMessage());
    }
}
}

