package Reportes;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import Modelo.Conexion;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ExcelCaja {

    public static void generar(String turno, String usuario) {
        Workbook book = new XSSFWorkbook();
        Sheet sheet = book.createSheet("Cierre de Caja");

        try {
            InputStream is = new FileInputStream("src/Imagenes/LogoAT.png");
            byte[] bytes = IOUtils.toByteArray(is);
            int imgIndex = book.addPicture(bytes, Workbook.PICTURE_TYPE_PNG);
            is.close();

            CreationHelper help = book.getCreationHelper();
            Drawing draw = sheet.createDrawingPatriarch();
            ClientAnchor anchor = help.createClientAnchor();
            anchor.setCol1(0);
            anchor.setRow1(1);
            Picture pict = draw.createPicture(anchor, imgIndex);
            pict.resize(1, 3);

            CellStyle tituloEstilo = book.createCellStyle();
            tituloEstilo.setAlignment(HorizontalAlignment.CENTER);
            tituloEstilo.setVerticalAlignment(VerticalAlignment.CENTER);
            Font fuenteTitulo = book.createFont();
            fuenteTitulo.setFontName("Berlin Sans FB");
            fuenteTitulo.setBold(true);
            fuenteTitulo.setFontHeightInPoints((short) 14);
            tituloEstilo.setFont(fuenteTitulo);

            Row filaTitulo = sheet.createRow(1);
            Cell celdaTitulo = filaTitulo.createCell(1);
            celdaTitulo.setCellStyle(tituloEstilo);
            celdaTitulo.setCellValue("Cierre de Caja - Turno " + turno);

            sheet.addMergedRegion(new CellRangeAddress(1, 2, 1, 5));

            // ✅ NUEVA CABECERA con "Método de Pago"
            String[] cabecera = new String[]{"ID Venta", "Cliente", "Vendedor", "Total", "Método de Pago", "Fecha"};

            CellStyle headerStyle = book.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.SEA_GREEN.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);

            Font font = book.createFont();
            font.setFontName("Arial");
            font.setBold(true);
            font.setColor(IndexedColors.WHITE.getIndex());
            font.setFontHeightInPoints((short) 12);
            headerStyle.setFont(font);

            Row filaEncabezados = sheet.createRow(4);
            for (int i = 0; i < cabecera.length; i++) {
                Cell celdaEncabezado = filaEncabezados.createCell(i);
                celdaEncabezado.setCellStyle(headerStyle);
                celdaEncabezado.setCellValue(cabecera[i]);
            }

            Conexion con = new Conexion();
            PreparedStatement ps;
            ResultSet rs;
            Connection conn = con.getConnection();

            // 🕒 Filtrar por turno
            String horaInicio = "06:00:00";
            String horaFin = "13:59:59";
            if (turno.equalsIgnoreCase("Tarde")) {
                horaInicio = "14:00:00";
                horaFin = "23:59:59";
            }

            // ✅ Actualizado: incluye metodopago
            String sql = "SELECT id, cliente, vendedor, total, metodopago, fecha FROM ventas "
                    + "WHERE vendedor = ? AND TIME(fecha) BETWEEN ? AND ? AND DATE(fecha) = CURDATE()";

            ps = conn.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, horaInicio);
            ps.setString(3, horaFin);

            rs = ps.executeQuery();

            int numFilaDatos = 5;
            CellStyle datosEstilo = book.createCellStyle();
            datosEstilo.setBorderBottom(BorderStyle.THIN);
            datosEstilo.setBorderLeft(BorderStyle.THIN);
            datosEstilo.setBorderRight(BorderStyle.THIN);

            while (rs.next()) {
                Row filaDatos = sheet.createRow(numFilaDatos);
                for (int i = 0; i < 6; i++) {
                    Cell celdaDatos = filaDatos.createCell(i);
                    celdaDatos.setCellStyle(datosEstilo);
                    celdaDatos.setCellValue(rs.getString(i + 1));
                }
                numFilaDatos++;
            }

            for (int i = 0; i < 6; i++) {
                sheet.autoSizeColumn(i);
            }

            sheet.setZoom(150);
            String fileName = "cierre_caja_" + turno.toLowerCase();
            String home = System.getProperty("user.home");
            File file = new File(home + "/Downloads/" + fileName + ".xlsx");
            FileOutputStream fileOut = new FileOutputStream(file);
            book.write(fileOut);
            fileOut.close();
            Desktop.getDesktop().open(file);
            JOptionPane.showMessageDialog(null, "Cierre de caja exportado con éxito");

        } catch (Exception ex) {
            Logger.getLogger(ExcelCaja.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Error al generar cierre: " + ex.getMessage());
        }
    }
}

